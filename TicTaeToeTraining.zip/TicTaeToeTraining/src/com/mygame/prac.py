import math
BW= input("Enter the bandwidth to be alloted in (KHz): ")
SCS=input("Enter subcarrier spacing to be alloted in (KHz): ")
STD=input("Enter the standard to be followed 0 for MCS index and 1 for CQI: ")
index=input("Enter the index: ")
MIMO=input("Enter MIMO layer (1-4): ")
mcs=[0.2344, 0.377, 0.6016, 0.877,1.1758,1.4766,1.6953,1.9141,2.1602,2.4063,2.5703,2.7035,3.0293,3.3223,3.6094,3.9023,4.2129,4.5234,4.8164,5.1152,5.3320,5.5547,5.8906,6.2266,6.5703,6.9141,
            7.1602,7.4063]
cqi=[0.1523,0.1523,0.377,0.877,1.4766,1.9141,2.4063,2.7053,3.3223,3.9023,4.5234,5.1152,5.5547,6.2266,6.9141,7.4063]
if STD=="0":
    noOfBits=mcs[int(index)]*132
else:
    noOfBits=cqi[int(index)]*132
PRB=math.floor(int(BW)/(int(SCS)*12))-4
slots=1600
print("Throughput: ",int((slots*PRB*int(MIMO)*int(noOfBits))/1000000)," Mbps" )