package com.mygame;

public class Main {
	public static void main(String [] args) {
		System.out.println("Program started..");
		MyGame game=new MyGame();
//		 Data game=new Data();
//		UserLogin new1=new UserLogin();
	}
}
