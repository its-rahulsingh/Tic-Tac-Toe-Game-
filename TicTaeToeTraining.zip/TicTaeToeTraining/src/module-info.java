module ticTaeToeTraining {
	requires java.desktop;
	requires java.sql;
}